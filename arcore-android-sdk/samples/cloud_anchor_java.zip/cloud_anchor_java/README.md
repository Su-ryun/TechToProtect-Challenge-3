# ARCore Cloud Anchors Sample

This is a sample app demonstrating how ARCore anchors can be hosted and resolved
using the ARCore Cloud Service.

## Getting Started

 See [Get started with Cloud Anchors for Android](https://developers.google.com/ar/develop/java/cloud-anchors/cloud-anchors-quickstart-android)
 to learn how to set up your development environment and try out this sample app.
