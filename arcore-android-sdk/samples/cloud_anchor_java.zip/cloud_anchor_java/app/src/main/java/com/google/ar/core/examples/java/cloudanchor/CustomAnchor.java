package com.google.ar.core.examples.java.cloudanchor;

public class CustomAnchor {

    String assetName = "models/andy.obj";

    public String assetName() {
        return assetName;
    }
}
