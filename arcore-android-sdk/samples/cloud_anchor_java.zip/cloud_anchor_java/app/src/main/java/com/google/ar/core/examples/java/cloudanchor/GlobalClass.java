package com.google.ar.core.examples.java.cloudanchor;

public class GlobalClass {
    public static float rotateF = 0.00f;
    public static float scaleFactor = 1.0f;
}
